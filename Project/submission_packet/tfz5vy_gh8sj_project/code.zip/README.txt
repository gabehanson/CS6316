README FILE FOR .PY FILES 

To run the .py files, ensure that the datasets (dataset 1 and dataset 2 are in the same)
folder as the .py files.

Run .py files in terminal by cd into the folder with the .py and dataset files, then
running them using:

python LogisitcRegression.py	OR
python DecisionTree.py          OR
python RandomForest.py          OR
python Boosting.py

After running these files they should print all necessary metrics of each of the 
4 implementations for a given classifier for both the testing and the training
sets. 

